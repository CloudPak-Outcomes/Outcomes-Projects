IDENTAUTH = "icp4d-api/v1/authorize"
USRMGMT = "usermgmt/v1/"