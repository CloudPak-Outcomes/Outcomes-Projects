IAM_ENDPOINT = "https://iam.cloud.ibm.com"
WATSON_DATA_ENDPOINT="https://api.dataplatform.cloud.ibm.com"
GLOBAL_CATALOG_ENDPOINT = "https://globalcatalog.cloud.ibm.com/api/v1"
USER_MGMT_ENDPOINT="https://user-management.cloud.ibm.com"
RESOURCE_ENDPOINT="https://resource-controller.cloud.ibm.com"
DV_ENDPOINT = 'https://us-south.data-virtualization.cloud.ibm.com'
