

#!
set -euo pipefail

source .env

##
## SaaS API Versions - see https://cloud.ibm.com/apidocs/watsonx-ai#active-version-dates
##
# apiversion="2024-03-14"
apiversion="2024-10-08"

##
## Convert API key to a bearer token
##
bearertoken=$(curl --no-progress-meter -X POST 'https://iam.cloud.ibm.com/identity/token' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -d "grant_type=urn:ibm:params:oauth:grant-type:apikey&apikey=${apikey}" \
  | jq -r '.access_token')

  
##
## Submit the exercise
##
sed "s|\${projectid}|${projectid}|g" chat.json  \
  | curl --no-progress-meter \
  --header 'Accept: application/json' \
  --header 'Content-Type: application/json' \
  --header "Authorization: Bearer ${bearertoken}" \
  --data @- \
  -X POST \
  "https://${hostname}/ml/v1/text/chat?version=${apiversion}" \
  | tee output.log \
  | jq .
